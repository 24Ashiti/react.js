import React from 'react'

const Blog = () => {
  return (
    <div>
       <h1 className='text-2xl font-bold text-center'>This is Blog Page</h1>
    </div>
  )
}

export default Blog
