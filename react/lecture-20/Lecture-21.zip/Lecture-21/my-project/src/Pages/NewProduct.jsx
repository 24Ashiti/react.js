import React from 'react'

const NewProduct = () => {
  return (
    <div>
      <h1>This is NewProduct Page</h1>
    </div>
  )
}

export default NewProduct
