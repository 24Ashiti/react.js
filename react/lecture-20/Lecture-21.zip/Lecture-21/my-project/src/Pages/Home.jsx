import React from 'react'

const Home = () => {
  return (
    <div>
      <h1 className='text-2xl font-bold text-center'>This is Home Page</h1>
    </div>
  )
}

export default Home
