import React from 'react'

const Contact = () => {
  return (
    <div>
       <h1 className='text-2xl font-bold text-center'>This is Contact Page</h1>
    </div>
  )
}

export default Contact
