import React from 'react'

const AboutUs = () => {
  return (
    <div>
       <h1 className='text-2xl font-bold text-center'>This is AboutUs Page</h1>
    </div>
  )
}

export default AboutUs
