import React from 'react'

const ProductFratures = () => {
  return (
    <div>
      <h1>This is ProductFeatures Page</h1>
    </div>
  )
}

export default ProductFratures
